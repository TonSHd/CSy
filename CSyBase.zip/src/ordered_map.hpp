#pragma once

#include <cstddef>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace csy {

template <class V>
class OrderedMap {
public:
    using value_type = std::pair<std::string, V>;
    using iterator = typename std::vector<value_type>::iterator;
    using const_iterator = typename std::vector<value_type>::const_iterator;

    iterator begin() { return entries_.begin(); }
    iterator end() { return entries_.end(); }
    const_iterator begin() const { return entries_.begin(); }
    const_iterator end() const { return entries_.end(); }

    size_t size() const { return entries_.size(); }
    bool empty() const { return entries_.empty(); }
    void reserve(size_t n) { entries_.reserve(n); index_.reserve(n); }
    void clear() { entries_.clear(); index_.clear(); }

    size_t count(const std::string& key) const { return index_.count(key); }
    bool contains(const std::string& key) const { return index_.count(key) != 0; }

    iterator find(const std::string& key) {
        auto it = index_.find(key);
        return it == index_.end() ? entries_.end() : entries_.begin() + static_cast<std::ptrdiff_t>(it->second);
    }
    const_iterator find(const std::string& key) const {
        auto it = index_.find(key);
        return it == index_.end() ? entries_.end() : entries_.begin() + static_cast<std::ptrdiff_t>(it->second);
    }

    V& operator[](const std::string& key) {
        auto it = index_.find(key);
        if (it != index_.end()) return entries_[it->second].second;
        index_.emplace(key, entries_.size());
        entries_.emplace_back(key, V());
        return entries_.back().second;
    }

    const V& at(const std::string& key) const {
        auto it = index_.find(key);
        if (it == index_.end()) throw std::out_of_range("key not found");
        return entries_[it->second].second;
    }

    std::pair<iterator, bool> emplace(const std::string& key, V value) {
        auto it = index_.find(key);
        if (it != index_.end()) return {entries_.begin() + static_cast<std::ptrdiff_t>(it->second), false};
        index_.emplace(key, entries_.size());
        entries_.emplace_back(key, std::move(value));
        return {entries_.end() - 1, true};
    }

    bool erase(const std::string& key) {
        auto it = index_.find(key);
        if (it == index_.end()) return false;
        const size_t pos = it->second;
        index_.erase(it);
        entries_.erase(entries_.begin() + static_cast<std::ptrdiff_t>(pos));
        for (size_t i = pos; i < entries_.size(); i++) index_[entries_[i].first] = i;
        return true;
    }

private:
    std::vector<value_type> entries_;
    std::unordered_map<std::string, size_t> index_;
};

}
