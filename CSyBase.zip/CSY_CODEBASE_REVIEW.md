# CSy Codebase Review

Review date: 2026-11-01

## Findings

### High: Function values are assigned before their union member is constructed

**Locations:** `src/vm.cpp:1073-1081`, `src/vm.cpp:1155-1171`

`Value` stores its payload in a union. These VM paths set `type` to `Value::Func` and assign to `func_val` directly, unlike the `Value::make_func` factory, which constructs the `Rc<Function>` member with placement new. Assigning to an inactive union member this way does not begin the member's lifetime and is undefined behavior in C++. The paths cover cached user functions, builtins, closures, and self references.

### Medium: `bc::sort_by` does not define ordering for NaN keys

**Location:** `src/builtins_std.cpp:383-388`

Float keys are compared with `<` without a NaN case. If the key function returns NaN for at least one item, the comparator may violate the strict-weak-ordering requirement of `std::stable_sort`, making the result unspecified and potentially invoking undefined behavior.

### Medium: Repeated dictionary removal has quadratic cost

**Location:** `src/ordered_map.hpp:63-69`

Each successful erase shifts later entries in the vector and updates their positions in the index map. Repeated removals therefore take O(n²) total time. The dictionary branch of `bc::remove(dict, key)` uses this operation.

Measured removal time with a small standalone C++ benchmark that populated an `OrderedMap<int>` and erased its keys in insertion order:

| Entries | Erase time |
|---:|---:|
| 5,000 | 247 ms |
| 10,000 | 1,081 ms |
| 20,000 | 5,126 ms |

## Performance Baseline

Best of five runs from `RUNS=5 bash scripts/bench.sh`; times are milliseconds. These are interpreter/native-backend benchmark results, not native-AOT timings.

| Benchmark | VM | C | x64 | Auto | C++ |
|---|---:|---:|---:|---:|---:|
| collatz | 1,389 | 47 | 73 | 48 | 32 |
| dict_count | 163 | 159 | 157 | 157 | — |
| fib | 447 | 8 | 17 | 9 | 4 |
| integrate | 2,064 | 195 | 246 | 197 | 193 |
| primes | 11,744 | 512 | 519 | 512 | 509 |
| sieve | 605 | 38 | 40 | 39 | 26 |
| vec_build | 144 | 145 | 143 | 144 | — |

The `fib` interpreter profile identified `VM::exec_function_impl` and `Value` destruction/reference-count operations as prominent costs. This is a profiling signal for future optimization, not a measured improvement.

## Verification Performed

- Differential tests: 31 cases passed with no differences.
- Native AOT acceptance tests passed.
- Process integration tests passed.
- Available cases passed under AddressSanitizer and UndefinedBehaviorSanitizer.
- Make and CMake builds succeeded.

The available tests do not establish coverage for all AI/MLP workloads, very large projects, or concurrent compiler memory-limit behavior. The review findings above remain unresolved.
