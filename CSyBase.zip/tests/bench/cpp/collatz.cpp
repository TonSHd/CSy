#include <cstdio>
static long long collatz(long long n) {
    long long s = 0;
    while (n != 1) { n = n % 2 == 0 ? n / 2 : 3 * n + 1; s++; }
    return s;
}
int main() {
    long long t = 0;
    for (long long i = 1; i < 300000; i++) t += collatz(i);
    std::printf("%lld\n", t);
}
