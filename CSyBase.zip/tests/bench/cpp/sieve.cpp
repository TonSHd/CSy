#include <cstdio>
#include <vector>
int main() {
    const long long n = 5000000;
    std::vector<double> f(n, 1.0);
    for (long long i = 2; i * i < n; i++)
        if (f[i] > 0.5) for (long long j = i * i; j < n; j += i) f[j] = 0.0;
    long long c = 0;
    for (long long k = 2; k < n; k++) if (f[k] > 0.5) c++;
    std::printf("%lld\n", c);
}
