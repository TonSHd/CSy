#include <cstdio>
static bool is_prime(long long n) {
    if (n < 2) return false;
    for (long long i = 2; i * i <= n; i++) if (n % i == 0) return false;
    return true;
}
int main() {
    long long c = 0;
    for (long long i = 0; i < 3000000; i++) if (is_prime(i)) c++;
    std::printf("%lld\n", c);
}
