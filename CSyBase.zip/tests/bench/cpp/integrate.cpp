#include <cstdio>
#include <cmath>
int main() {
    const long long n = 20000000;
    double h = 1.0 / n, s = 0.0;
    for (long long i = 0; i < n; i++) { double x = (i + 0.5) * h; s += std::sin(x) * std::exp(0.0 - x); }
    std::printf("%g\n", s * h);
}
