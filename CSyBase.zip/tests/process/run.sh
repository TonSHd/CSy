#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
csyc="${CSYC:-$root/csyc}"
work="$(mktemp -d /tmp/csyc-process-tests.XXXXXX)"
trap 'rm -rf -- "$work"' EXIT
mkdir -p "$work/home/.config" "$work/bin"
printf '#!/bin/sh\nexec "$@"\n' >"$work/bin/sudo"
chmod 700 "$work/bin/sudo"
export HOME="$work/home"
export XDG_CONFIG_HOME="$work/home/.config"
export CSY_NO_NATIVE_JIT=1
export PATH="$work/bin:/usr/bin:/bin"

build_and_run() {
    local name="$1" approvals="$2" runtime_input="${3:-}"
    local source="$root/tests/process/$name.csy"
    local object="$work/$name.cso"
    printf '%s' "$approvals" | "$csyc" build "$source" -o "$object" >"$work/$name.build.out" 2>"$work/$name.build.err"
    printf '%s' "$runtime_input" | timeout 3 "$csyc" run "$object" >"$work/$name.out" 2>"$work/$name.err"
    diff -u "$root/tests/process/$name.expected" "$work/$name.out"
}

build_and_run argv $'1\n'
build_and_run options $'1\n1\n1\n1\n'
build_and_run shell $'1\n'
printf 'yes\nyes\n' | build_and_run elevated $'1\n' $'yes\nyes\n'
printf '1\n' | "$csyc" build "$root/tests/process/interactive.csy" -o "$work/interactive.cso" >"$work/interactive.build.out" 2>"$work/interactive.build.err"
python3 "$root/tests/process/interactive.py" "$csyc" "$work/interactive.cso"
grep -q 'warning: .*external command call requires approval' "$work/argv.build.err"
grep -q 'aight. fine' "$work/elevated.err"
test ! -e "$root/tests/process/command-trust"
if printf '2\n' | "$csyc" build "$root/tests/process/denied.csy" -o "$work/denied.cso" >"$work/denied.out" 2>"$work/denied.err"; then
    printf 'denied process call unexpectedly built\n' >&2
    exit 1
fi
test ! -e "$work/denied.cso"
printf 'process tests passed\n'
