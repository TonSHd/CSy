import os
import pty
import select
import signal
import sys
import time

pid, master = pty.fork()
if pid == 0:
    os.execv(sys.argv[1], [sys.argv[1], "run", sys.argv[2]])

output = bytearray()

def read_until(needle, seconds=5, start=0):
    deadline = time.monotonic() + seconds
    while needle not in output[start:] and time.monotonic() < deadline:
        ready, _, _ = select.select([master], [], [], 0.1)
        if not ready:
            continue
        try:
            chunk = os.read(master, 4096)
        except OSError:
            break
        if chunk:
            output.extend(chunk)
    if needle not in output[start:]:
        raise SystemExit("interactive Bash did not print " + repr(needle) + "\n" +
                         output.decode(errors="replace"))

os.write(master, b"sudo /usr/bin/printf interactive-safe\n")
read_until(b"Are you sure?")
os.write(master, b"yes\n")
read_until(b"Are you REALLY sure?")
after_confirmation = len(output)
os.write(master, b"yes\n")
read_until(b"$ ", start=after_confirmation)
os.write(master, b"exit\n")
deadline = time.monotonic() + 5
status = None
while time.monotonic() < deadline:
    waited, raw_status = os.waitpid(pid, os.WNOHANG)
    if waited == pid:
        status = os.waitstatus_to_exitcode(raw_status)
        break
    ready, _, _ = select.select([master], [], [], 0.1)
    if ready:
        try:
            chunk = os.read(master, 4096)
        except OSError:
            waited, raw_status = os.waitpid(pid, os.WNOHANG)
            if waited == pid:
                status = os.waitstatus_to_exitcode(raw_status)
            break
        if chunk:
            output.extend(chunk)
if status is None:
    os.kill(pid, signal.SIGKILL)
    os.waitpid(pid, 0)
    raise SystemExit("interactive Bash did not exit\n" + output.decode(errors="replace"))
os.close(master)
text = output.decode(errors="replace")
for expected in ("Are you sure?", "Are you REALLY sure?", "aight. fine", "interactive-safe"):
    if expected not in text:
        raise SystemExit("interactive Bash output is missing: " + expected + "\n" + text)
if status != 0:
    raise SystemExit("interactive Bash exited with status " + str(status) + "\n" + text)
