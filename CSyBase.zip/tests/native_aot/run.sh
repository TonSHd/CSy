#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
csyc="${CSYC:-$root/csyc}"
work="$(mktemp -d /tmp/csyc-native-aot.XXXXXX)"
trap 'rm -rf -- "$work"' EXIT

"$csyc" build "$root/tests/native_aot/main.csy" --native-exe -o "$work/native" >"$work/build.out" 2>"$work/build.err"
readelf -h "$work/native" | grep -q 'Machine:.*X86-64'
set +e
PATH=/nonexistent "$work/native"
status=$?
set -e
test "$status" -eq 42

if "$csyc" build "$root/tests/native_aot/overflow.csy" --native-exe -o "$work/overflow" >"$work/overflow.build.out" 2>"$work/overflow.build.err"; then
    set +e
    "$work/overflow" >"$work/overflow.out" 2>"$work/overflow.err"
    status=$?
    set -e
    test "$status" -eq 1
    grep -q 'integer overflow in addition' "$work/overflow.err"
else
    printf 'supported integer overflow test did not build\n' >&2
    exit 1
fi

if "$csyc" build "$root/tests/native_aot/unsupported.csy" --native-exe -o "$work/unsupported" >"$work/unsupported.out" 2>"$work/unsupported.err"; then
    printf 'unsupported native source unexpectedly built\n' >&2
    exit 1
fi
test ! -e "$work/unsupported"
grep -q 'native-only build' "$work/unsupported.err"

if "$csyc" build "$root/tests/native_aot/main.csy" --native-exe >"$work/missing-output.out" 2>"$work/missing-output.err"; then
    printf 'native AOT build unexpectedly accepted a missing output path\n' >&2
    exit 1
fi

if "$csyc" build "$root/tests/native_aot/main.csy" --native-exe --exe -o "$work/conflicting" >"$work/conflicting.out" 2>"$work/conflicting.err"; then
    printf 'native AOT build unexpectedly accepted --exe\n' >&2
    exit 1
fi
test ! -e "$work/conflicting"
printf 'native AOT tests passed\n'
